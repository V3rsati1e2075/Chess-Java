package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Pieces.Pos;
import Pieces.Piece;

import javax.swing.*;

public class VisualizeBoard implements ActionListener  {

    public VisualizeBoard(Piece [][]board) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
