import src.AddPieces;
import src.FrameWork;
import Game.GameEngine;
import java.util.ArrayList;
import java.util.*;
import src.FrameWork;
import Pieces.Pos;
import Pieces.Piece;
import Pieces.Rook;
import Pieces.Bishop;
import Pieces.Queen;
import Pieces.Knight;
import Pieces.Pawn;
import Pieces.King;

public class Main {
    public static void main(String[] args) {
        FrameWork frame = new FrameWork() ;

    }
}