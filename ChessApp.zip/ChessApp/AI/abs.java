package AI;
import java.util.*;

public class abs {

}